package atv1;

public class veiculo {
	public int velocidade;
	public boolean status;
	
	public void ligarVeiculo(){
		status = true;
	}
	public void desligarVeiculo(){
		status = false;
	}
	public void acelerarVeiculo(){
		velocidade++;
	}
	public String mostrarStatus(){
		String mostrar = " ";
		if(status==true) 
		mostrar = "LIGADO";
		else
		mostrar = "DESLIGADO";
		return mostrar;
	}
}
