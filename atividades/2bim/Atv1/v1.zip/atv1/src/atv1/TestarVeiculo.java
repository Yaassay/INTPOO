package atv1;

public class TestarVeiculo {

	public static void main(String[] args) {
		veiculo v;
		v = new veiculo();
		
		v.velocidade = 150;
		v.status = false;
		
		v.ligarVeiculo();
		v.desligarVeiculo();
		v.ligarVeiculo();
		v.acelerarVeiculo();
		
		System.out.println(v.mostrarStatus());

	}

}
